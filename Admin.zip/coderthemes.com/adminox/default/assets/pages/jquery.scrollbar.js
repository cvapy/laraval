/**
* Theme: Adminox Dashboard
* Author: Coderthemes
* Scrollbars
*/


$(".autohide-scroll").slimscroll({height:"auto",position:"right",size:"5px",color:"#9ea5ab"}),$(".visible-always-scroll").slimscroll({height:"auto",position:"right",size:"5px",color:"#9ea5ab",alwaysVisible:!0}),$(".color-scroll").slimscroll({height:"auto",color:"#64c5b1",position:"right",size:"5px"}),$(".scrollsize-scroll").slimscroll({height:"auto",color:"#333",size:"10px",position:"right",alwaysVisible:!0}),$(".scroll-rails-scroll").slimscroll({height:"auto",color:"#333",railVisible:!0,size:"8px",position:"right",alwaysVisible:!0}),$(".scroll-position-scroll").slimscroll({height:"auto",color:"#9ea5ab",size:"5px",position:"left",alwaysVisible:!0})
