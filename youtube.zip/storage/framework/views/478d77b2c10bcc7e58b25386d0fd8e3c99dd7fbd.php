<?php $__env->startSection('title'); ?>
Welcome
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <h3>Sign Up </h3>
        <form action="#" method="post">
            <div class="form-group">
                <label for="email">Your Email</label>
                <input class="form-control" type="text" name="email" id="email">
            </div>
            <div class="form-group">
                <label for="firstname">Your Name</label>
                <input class="form-control" type="text" name="firstname" id="firstname">
            </div>
            <div class="form-group">
                <label for="password">Your Password</label>
                <input class="form-control" type="password" name="password" id="password">
            </div>
            <button class="btn btn-primary">Submit</button>
        </form>
    </div>
    <div class="col-md-6">
        <h3>Sign In</h3>
        <form action="#" method="post">
            <div class="form-group">
                <label for="email">Your Email</label>
                <input class="form-control" type="text" name="email" id="email">
            </div>
            <div class="form-group">
                <label for="password">Your password</label>
                <input class="form-control" type="password" name="password" id="password">
            </div>
            <button class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>