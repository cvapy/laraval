<?php
namespace App\Http\Controller;

use App\User; 
use Illuminate\Http\Request;

class UserController extends Controller
{
	public function postSignUp(Request $request)
	{
		# code...
		$email = $request['email'];
		$name = $request['firstname'];
		$password = bcrypt($request['password']);//Helper function
		$user = new User();
		$user->email=$email;
		$user->=$firstname;$firstname;
		$user->password=$password;

		$user->save();
		return redirect()->back();




	}

	public function postSignIn(Request $request)
	{
		# code...
	}
}